#!/bin/sh
./miner --algo swap --server swap2.luckypool.io --port 4466 --user fh3N9LqnL3ievSNFboKUg1H3Q5e9bg5QZFK4XjpdPe6J8AWU42PNyAZPHdPrbSwm6ZaBDpW7Mc7Nk8ukCKKJRAt438izdAdqw
