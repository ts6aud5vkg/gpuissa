#!/bin/sh
./miner --algo 192_7 --pers ZERO_PoW --server equihash192.mine.zergpool.com --port 2144 --user t1d1YLkZ94UhUE1G6nJLHA2Qf3HPD5JqgwQ.rig0 --pass x
