#!/bin/sh
./miner --algo grin31 --server grin.sparkpool.com --port 6667 --user admin@develsoftware.com/rig0
