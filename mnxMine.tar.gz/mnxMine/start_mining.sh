#!/bin/bash
./mxminer -l eu -u XS14gShuJvwSXy5muKPshsU5DJjTUAjnx5 -t 2
